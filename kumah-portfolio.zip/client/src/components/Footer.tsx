/* ============================================================
   DESIGN: Cyberpunk Minimal Footer
   - Contact form with neon inputs
   - Resume download button
   - Social links + copyright
   ============================================================ */

import { useState, useRef, useEffect } from "react";
import { Github, Linkedin, Twitter, Mail, Download, Send, ArrowUpRight } from "lucide-react";
import { toast } from "sonner";

function useScrollReveal(threshold = 0.1) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setVisible(true); obs.disconnect(); } },
      { threshold }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, visible };
}

const SOCIAL_LINKS = [
  { icon: Github, label: "GitHub", href: "https://github.com/Desmond-Kumah" },
  { icon: Linkedin, label: "LinkedIn", href: "https://www.linkedin.com/in/desmond-kumah-45ab70355" },
  { icon: Mail, label: "Email", href: "mailto:kumah6128@gmail.com" },
];

const inputStyle = {
  width: "100%",
  background: "rgba(255,255,255,0.04)",
  border: "1px solid rgba(255,255,255,0.1)",
  borderRadius: "2px",
  padding: "0.75rem 1rem",
  color: "#e2e8f0",
  fontFamily: "Outfit, sans-serif",
  fontSize: "0.9rem",
  outline: "none",
  transition: "border-color 0.2s ease",
};

export default function Footer() {
  const { ref: sectionRef, visible } = useScrollReveal(0.1);
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [sending, setSending] = useState(false);
  const [focusedField, setFocusedField] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message) {
      toast.error("Please fill in all fields.");
      return;
    }
    setSending(true);
    // Simulate sending
    await new Promise((r) => setTimeout(r, 1200));
    setSending(false);
    toast.success("Message sent! I'll get back to you soon.", {
      style: {
        background: "#0D1117",
        border: "1px solid rgba(0, 255, 135, 0.3)",
        color: "#e2e8f0",
      },
    });
    setForm({ name: "", email: "", message: "" });
  };

  return (
    <footer id="contact" style={{ background: "#0D1117" }}>
      {/* Contact section */}
      <div className="py-24 relative overflow-hidden">
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: "radial-gradient(ellipse 60% 50% at 20% 80%, rgba(0, 255, 135, 0.05) 0%, transparent 70%)",
          }}
        />
        <div className="container relative z-10">
          <div
            ref={sectionRef}
            className="grid grid-cols-1 lg:grid-cols-2 gap-16"
          >
            {/* Left: Info */}
            <div
              style={{
                opacity: visible ? 1 : 0,
                transform: visible ? "translateX(0)" : "translateX(-24px)",
                transition: "opacity 0.7s ease, transform 0.7s ease",
              }}
            >
              <span className="section-label">05</span>
              <h2
                className="mt-3 mb-6"
                style={{
                  fontFamily: "Syne, sans-serif",
                  fontWeight: 800,
                  fontSize: "clamp(2rem, 5vw, 3.5rem)",
                  color: "#fff",
                  letterSpacing: "-0.02em",
                  lineHeight: 1.1,
                }}
              >
                Let's Build
                <br />
                <span style={{ color: "var(--neon)" }}>Something</span>
              </h2>

              <p
                className="mb-8 max-w-md"
                style={{ fontFamily: "Outfit, sans-serif", fontSize: "0.95rem", color: "var(--slate)", lineHeight: 1.8 }}
              >
                I'm currently open to full-time roles and interesting freelance
                projects. Whether you have a product idea, a technical challenge,
                or just want to talk code — my inbox is open.
              </p>

              {/* Contact details */}
              <div className="flex flex-col gap-4 mb-10">
                <a
                  href="mailto:kumah6128@gmail.com"
                  className="flex items-center gap-3 group"
                  style={{ textDecoration: "none" }}
                >
                  <div
                    className="w-10 h-10 flex items-center justify-center rounded-sm"
                    style={{ background: "rgba(0, 255, 135, 0.08)", border: "1px solid rgba(0, 255, 135, 0.2)" }}
                  >
                    <Mail size={15} color="var(--neon)" />
                  </div>
                  <div>
                    <div
                      style={{
                        fontFamily: "JetBrains Mono, monospace",
                        fontSize: "0.65rem",
                        color: "rgba(148,163,184,0.5)",
                        letterSpacing: "0.1em",
                        textTransform: "uppercase",
                        marginBottom: "0.1rem",
                      }}
                    >
                      Email
                    </div>
                    <div
                      className="group-hover:text-white transition-colors"
                      style={{ fontFamily: "Outfit, sans-serif", fontSize: "0.9rem", color: "var(--slate)" }}
                    >
                      kumah6128@gmail.com
                    </div>
                  </div>
                </a>
              </div>

              {/* Social links */}
              <div className="flex items-center gap-3 mb-10">
                {SOCIAL_LINKS.map(({ icon: Icon, label, href }) => (
                  <a
                    key={label}
                    href={href}
                    target="_blank"
                    rel="noopener noreferrer"
                    title={label}
                    className="w-10 h-10 flex items-center justify-center rounded-sm transition-all duration-200"
                    style={{
                      background: "rgba(255,255,255,0.04)",
                      border: "1px solid rgba(255,255,255,0.08)",
                      color: "var(--slate)",
                    }}
                    onMouseEnter={(e) => {
                      (e.currentTarget as HTMLElement).style.borderColor = "rgba(0, 255, 135, 0.4)";
                      (e.currentTarget as HTMLElement).style.color = "var(--neon)";
                      (e.currentTarget as HTMLElement).style.background = "rgba(0, 255, 135, 0.08)";
                    }}
                    onMouseLeave={(e) => {
                      (e.currentTarget as HTMLElement).style.borderColor = "rgba(255,255,255,0.08)";
                      (e.currentTarget as HTMLElement).style.color = "var(--slate)";
                      (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.04)";
                    }}
                  >
                    <Icon size={16} />
                  </a>
                ))}
              </div>

              {/* Resume download */}
              <a
                href="/resume-desmond-kumah.pdf"
                download
                className="btn-neon-solid inline-flex items-center gap-2"
                onClick={(e) => {
                  e.preventDefault();
                  toast.info("Resume download will be available soon!", {
                    style: {
                      background: "#0D1117",
                      border: "1px solid rgba(0, 255, 135, 0.3)",
                      color: "#e2e8f0",
                    },
                  });
                }}
              >
                <Download size={14} />
                Download Resume
              </a>
            </div>

            {/* Right: Contact form */}
            <div
              style={{
                opacity: visible ? 1 : 0,
                transform: visible ? "translateX(0)" : "translateX(24px)",
                transition: "opacity 0.7s ease 0.2s, transform 0.7s ease 0.2s",
              }}
            >
              <form onSubmit={handleSubmit} className="flex flex-col gap-5">
                <div>
                  <label
                    style={{
                      display: "block",
                      fontFamily: "JetBrains Mono, monospace",
                      fontSize: "0.68rem",
                      color: "var(--slate)",
                      letterSpacing: "0.12em",
                      textTransform: "uppercase",
                      marginBottom: "0.5rem",
                    }}
                  >
                    Name
                  </label>
                  <input
                    type="text"
                    value={form.name}
                    onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                    onFocus={() => setFocusedField("name")}
                    onBlur={() => setFocusedField(null)}
                    placeholder="Your name"
                    style={{
                      ...inputStyle,
                      borderColor: focusedField === "name" ? "rgba(0, 255, 135, 0.5)" : "rgba(255,255,255,0.1)",
                    }}
                  />
                </div>

                <div>
                  <label
                    style={{
                      display: "block",
                      fontFamily: "JetBrains Mono, monospace",
                      fontSize: "0.68rem",
                      color: "var(--slate)",
                      letterSpacing: "0.12em",
                      textTransform: "uppercase",
                      marginBottom: "0.5rem",
                    }}
                  >
                    Email
                  </label>
                  <input
                    type="email"
                    value={form.email}
                    onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
                    onFocus={() => setFocusedField("email")}
                    onBlur={() => setFocusedField(null)}
                    placeholder="your@email.com"
                    style={{
                      ...inputStyle,
                      borderColor: focusedField === "email" ? "rgba(0, 255, 135, 0.5)" : "rgba(255,255,255,0.1)",
                    }}
                  />
                </div>

                <div>
                  <label
                    style={{
                      display: "block",
                      fontFamily: "JetBrains Mono, monospace",
                      fontSize: "0.68rem",
                      color: "var(--slate)",
                      letterSpacing: "0.12em",
                      textTransform: "uppercase",
                      marginBottom: "0.5rem",
                    }}
                  >
                    Message
                  </label>
                  <textarea
                    value={form.message}
                    onChange={(e) => setForm((f) => ({ ...f, message: e.target.value }))}
                    onFocus={() => setFocusedField("message")}
                    onBlur={() => setFocusedField(null)}
                    placeholder="Tell me about your project or opportunity..."
                    rows={5}
                    style={{
                      ...inputStyle,
                      resize: "vertical",
                      borderColor: focusedField === "message" ? "rgba(0, 255, 135, 0.5)" : "rgba(255,255,255,0.1)",
                    }}
                  />
                </div>

                <button
                  type="submit"
                  disabled={sending}
                  className="btn-neon-solid flex items-center justify-center gap-2 w-full"
                  style={{ opacity: sending ? 0.7 : 1 }}
                >
                  {sending ? (
                    <>
                      <span
                        className="inline-block w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin"
                      />
                      Sending...
                    </>
                  ) : (
                    <>
                      <Send size={14} />
                      Send Message
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div
        className="border-t py-6"
        style={{ borderColor: "rgba(255,255,255,0.06)" }}
      >
        <div className="container flex flex-col sm:flex-row items-center justify-between gap-4">
          <div
            style={{
              fontFamily: "JetBrains Mono, monospace",
              fontSize: "0.72rem",
              color: "rgba(148,163,184,0.4)",
              letterSpacing: "0.05em",
            }}
          >
            © 2026 Desmond Kumah. Built with React + TypeScript.
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1" style={{ fontFamily: "JetBrains Mono, monospace", fontSize: "0.72rem", color: "rgba(148,163,184,0.4)" }}>
              <span>Designed & developed by</span>
              <span style={{ color: "var(--neon)", marginLeft: "0.3rem" }}>DK</span>
            </div>
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
              className="w-8 h-8 flex items-center justify-center rounded-sm transition-all duration-200"
              style={{
                background: "rgba(0, 255, 135, 0.08)",
                border: "1px solid rgba(0, 255, 135, 0.2)",
                color: "var(--neon)",
                fontSize: "0.8rem",
              }}
              title="Back to top"
            >
              ↑
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
