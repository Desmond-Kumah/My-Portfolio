/* ============================================================
   DESIGN: Cyberpunk Minimal Navbar
   - Sticky top bar, transparent → dark blur on scroll
   - JetBrains Mono nav links with neon underline reveal
   - [ DK ] logo mark in neon green
   ============================================================ */

import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";

const navItems = [
  { label: "about", href: "#about" },
  { label: "projects", href: "#projects" },
  { label: "skills", href: "#skills" },
  { label: "blog", href: "#blog" },
  { label: "contact", href: "#contact" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const handleNavClick = (href: string) => {
    setMobileOpen(false);
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <header
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
      style={{
        background: scrolled
          ? "rgba(5, 10, 14, 0.92)"
          : "transparent",
        backdropFilter: scrolled ? "blur(12px)" : "none",
        borderBottom: scrolled ? "1px solid rgba(0, 255, 135, 0.08)" : "none",
      }}
    >
      <div className="container flex items-center justify-between py-4">
        {/* Logo */}
        <a
          href="#"
          onClick={(e) => { e.preventDefault(); window.scrollTo({ top: 0, behavior: "smooth" }); }}
          className="flex items-center gap-2 group"
        >
          <span
            className="font-mono text-sm font-600 px-2 py-1 border border-current"
            style={{ color: "var(--neon)", fontFamily: "JetBrains Mono, monospace", fontSize: "0.85rem", fontWeight: 600 }}
          >
            DK
          </span>
          <span
            className="hidden sm:block text-sm"
            style={{ fontFamily: "JetBrains Mono, monospace", color: "var(--slate)", fontSize: "0.75rem", letterSpacing: "0.08em" }}
          >
            desmond.kumah
          </span>
        </a>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          {navItems.map((item) => (
            <a
              key={item.label}
              href={item.href}
              className="nav-link"
              onClick={(e) => { e.preventDefault(); handleNavClick(item.href); }}
            >
              {item.label}
            </a>
          ))}
          <a
            href="#contact"
            className="btn-neon text-xs"
            onClick={(e) => { e.preventDefault(); handleNavClick("#contact"); }}
          >
            hire me
          </a>
        </nav>

        {/* Mobile toggle */}
        <button
          className="md:hidden p-2"
          style={{ color: "var(--neon)" }}
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-label="Toggle menu"
        >
          {mobileOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div
          className="md:hidden border-t"
          style={{
            background: "rgba(5, 10, 14, 0.98)",
            borderColor: "rgba(0, 255, 135, 0.1)",
          }}
        >
          <nav className="container flex flex-col gap-1 py-4">
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                className="py-3 border-b text-sm"
                style={{
                  fontFamily: "JetBrains Mono, monospace",
                  color: "var(--slate)",
                  borderColor: "rgba(255,255,255,0.05)",
                  letterSpacing: "0.08em",
                }}
                onClick={(e) => { e.preventDefault(); handleNavClick(item.href); }}
              >
                <span style={{ color: "var(--neon)", marginRight: "0.5rem" }}>&gt;</span>
                {item.label}
              </a>
            ))}
            <a
              href="#contact"
              className="btn-neon mt-3 self-start"
              onClick={(e) => { e.preventDefault(); handleNavClick("#contact"); }}
            >
              hire me
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}
