/* ============================================================
   DESIGN: Cyberpunk Minimal Projects Grid
   - Mixed-size card grid (1 featured + smaller cards)
   - Neon border reveal on hover
   - Tech tags in JetBrains Mono
   - Live demo + repo link buttons
   ============================================================ */

import { useRef, useEffect, useState } from "react";
import { Github, ExternalLink, Star, GitFork } from "lucide-react";

const PROJECTS = [
  {
    id: 1,
    title: "NexusDB",
    description:
      "A high-performance distributed key-value store built in Go with Raft consensus algorithm. Supports horizontal scaling, automatic failover, and sub-millisecond read latency across 10k+ concurrent connections.",
    tags: ["Go", "Raft", "gRPC", "Docker", "Kubernetes"],
    stars: 847,
    forks: 134,
    demo: "https://nexusdb.dev",
    repo: "https://github.com/desmondkumah/nexusdb",
    featured: true,
    status: "Production",
  },
  {
    id: 2,
    title: "ReactFlow Studio",
    description:
      "Visual node-based workflow editor for building data pipelines. Drag-and-drop interface with real-time execution preview and TypeScript-first API.",
    tags: ["React", "TypeScript", "WebSockets", "Canvas API"],
    stars: 523,
    forks: 89,
    demo: "https://reactflow-studio.vercel.app",
    repo: "https://github.com/desmondkumah/reactflow-studio",
    featured: false,
    status: "Active",
  },
  {
    id: 3,
    title: "GraphQL Forge",
    description:
      "Auto-generates type-safe GraphQL schemas from TypeScript interfaces. Zero-config setup with support for custom resolvers and middleware.",
    tags: ["GraphQL", "TypeScript", "Node.js", "AST"],
    stars: 312,
    forks: 47,
    demo: null,
    repo: "https://github.com/desmondkumah/graphql-forge",
    featured: false,
    status: "Stable",
  },
  {
    id: 4,
    title: "CloudTrace",
    description:
      "Distributed tracing dashboard for microservices. Visualizes request flows across services with latency heatmaps and anomaly detection.",
    tags: ["React", "D3.js", "OpenTelemetry", "PostgreSQL"],
    stars: 198,
    forks: 31,
    demo: "https://cloudtrace.io",
    repo: "https://github.com/desmondkumah/cloudtrace",
    featured: false,
    status: "Beta",
  },
  {
    id: 5,
    title: "AuthKit",
    description:
      "Plug-and-play authentication library for Node.js. JWT, OAuth2, RBAC, and MFA in a single package with Express/Fastify adapters.",
    tags: ["Node.js", "JWT", "OAuth2", "TypeScript"],
    stars: 441,
    forks: 78,
    demo: "https://authkit.dev/docs",
    repo: "https://github.com/desmondkumah/authkit",
    featured: false,
    status: "Production",
  },
];

function useScrollReveal(threshold = 0.1) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setVisible(true); obs.disconnect(); } },
      { threshold }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, visible };
}

function ProjectCard({ project, index, featured = false }: { project: typeof PROJECTS[0]; index: number; featured?: boolean }) {
  const { ref, visible } = useScrollReveal(0.1);

  const statusColors: Record<string, string> = {
    Production: "#00FF87",
    Active: "#60A5FA",
    Stable: "#A78BFA",
    Beta: "#FBBF24",
  };

  return (
    <div
      ref={ref}
      className="card-neon rounded-sm p-6 flex flex-col gap-4 relative overflow-hidden"
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? "translateY(0)" : "translateY(24px)",
        transition: `opacity 0.6s ease ${index * 0.1}s, transform 0.6s ease ${index * 0.1}s`,
      }}
    >
      {/* Top accent line */}
      <div
        className="absolute top-0 left-0 right-0 h-px"
        style={{
          background: "linear-gradient(90deg, transparent, var(--neon), transparent)",
          opacity: 0.4,
        }}
      />

      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <span
              style={{
                fontFamily: "JetBrains Mono, monospace",
                fontSize: "0.65rem",
                color: statusColors[project.status] || "var(--neon)",
                letterSpacing: "0.1em",
                textTransform: "uppercase",
                padding: "0.15rem 0.5rem",
                border: `1px solid ${statusColors[project.status] || "var(--neon)"}40`,
                borderRadius: "2px",
              }}
            >
              {project.status}
            </span>
            {featured && (
              <span
                style={{
                  fontFamily: "JetBrains Mono, monospace",
                  fontSize: "0.65rem",
                  color: "#FBBF24",
                  letterSpacing: "0.1em",
                  textTransform: "uppercase",
                  padding: "0.15rem 0.5rem",
                  border: "1px solid rgba(251, 191, 36, 0.3)",
                  borderRadius: "2px",
                }}
              >
                ★ Featured
              </span>
            )}
          </div>
          <h3
            style={{
              fontFamily: "Syne, sans-serif",
              fontWeight: 700,
              fontSize: featured ? "1.75rem" : "1.1rem",
              color: "#fff",
              letterSpacing: "-0.02em",
            }}
          >
            {project.title}
          </h3>
        </div>

        {/* Stats */}
        <div className="flex items-center gap-3 shrink-0">
          <span
            className="flex items-center gap-1"
            style={{ fontFamily: "JetBrains Mono, monospace", fontSize: "0.72rem", color: "var(--slate)" }}
          >
            <Star size={12} />
            {project.stars}
          </span>
          <span
            className="flex items-center gap-1"
            style={{ fontFamily: "JetBrains Mono, monospace", fontSize: "0.72rem", color: "var(--slate)" }}
          >
            <GitFork size={12} />
            {project.forks}
          </span>
        </div>
      </div>

      {/* Description */}
      <p
        style={{
          fontFamily: "Outfit, sans-serif",
          fontSize: "0.9rem",
          color: "var(--slate)",
          lineHeight: 1.7,
          flex: 1,
        }}
      >
        {project.description}
      </p>

      {/* Tags */}
      <div className="flex flex-wrap gap-2">
        {project.tags.map((tag) => (
          <span key={tag} className="tech-tag" style={{display: 'none'}} style={{display: 'none'}} style={{display: 'none'}} style={{display: 'none'}}>{tag}</span>
        ))}
      </div>

      {/* Links */}
      <div className="flex items-center gap-3 pt-2 border-t" style={{ borderColor: "rgba(255,255,255,0.06)" }}>
        <a
          href={project.repo}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-1.5 text-sm transition-colors duration-200"
          style={{
            fontFamily: "JetBrains Mono, monospace",
            fontSize: "0.75rem",
            color: "var(--slate)",
            letterSpacing: "0.05em",
          }}
          onMouseEnter={(e) => (e.currentTarget.style.color = "var(--neon)")}
          onMouseLeave={(e) => (e.currentTarget.style.color = "var(--slate)")}
        >
          <Github size={13} />
          Source
        </a>
        {project.demo && (
          <a
            href={project.demo}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 transition-colors duration-200"
            style={{
              fontFamily: "JetBrains Mono, monospace",
              fontSize: "0.75rem",
              color: "var(--neon)",
              letterSpacing: "0.05em",
            }}
            onMouseEnter={(e) => (e.currentTarget.style.opacity = "0.7")}
            onMouseLeave={(e) => (e.currentTarget.style.opacity = "1")}
          >
            <ExternalLink size={13} />
            Live Demo
          </a>
        )}
      </div>
    </div>
  );
}

export default function Projects() {
  const { ref: headerRef, visible: headerVisible } = useScrollReveal(0.2);

  return (
    <section id="projects" className="py-24 relative overflow-hidden" style={{ background: "#050A0E" }}>
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: "radial-gradient(ellipse 70% 50% at 50% 100%, rgba(0, 255, 135, 0.04) 0%, transparent 70%)",
        }}
      />
      <div className="container relative z-10">
        {/* Section header */}
        <div
          ref={headerRef}
          className="mb-16"
          style={{
            opacity: headerVisible ? 1 : 0,
            transform: headerVisible ? "translateY(0)" : "translateY(20px)",
            transition: "opacity 0.6s ease, transform 0.6s ease",
          }}
        >
          <span className="section-label">02</span>
          <h2
            className="mt-3"
            style={{
              fontFamily: "Syne, sans-serif",
              fontWeight: 800,
              fontSize: "clamp(2rem, 5vw, 3.5rem)",
              color: "#fff",
              letterSpacing: "-0.02em",
              lineHeight: 1.1,
            }}
          >
            Selected Projects
          </h2>
          <p
            className="mt-4 max-w-lg"
            style={{ fontFamily: "Outfit, sans-serif", fontSize: "0.95rem", color: "var(--slate)", lineHeight: 1.7 }}
          >
            A curated selection of open-source projects and production applications.
            Each project reflects a specific engineering challenge and solution.
          </p>
          <div className="scan-divider mt-8" />
        </div>

        {/* Project grid */}
        <div className="flex flex-col gap-4">
          {/* Featured project - full width */}
          <ProjectCard project={PROJECTS[0]} index={0} featured />
          {/* Remaining projects - responsive grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {PROJECTS.slice(1).map((project, i) => (
              <ProjectCard key={project.id} project={project} index={i + 1} />
            ))}
          </div>
        </div>

        {/* View all link */}
        <div className="mt-12 flex justify-center">
          <a
            href="https://github.com/desmondkumah"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-neon"
          >
            <Github size={14} />
            View All on GitHub
          </a>
        </div>
      </div>
    </section>
  );
}
