/* ============================================================
   DESIGN: Cyberpunk Minimal Hero
   - Full-viewport, left-aligned content
   - Oversized Syne display name with glitch animation
   - Typewriter role descriptor in JetBrains Mono
   - Tech stack icon row + GitHub CTA
   - Background: generated hero-bg image with dark overlay
   ============================================================ */

import { useEffect, useState, useRef } from "react";
import { Github, ArrowDown, ExternalLink } from "lucide-react";

const ROLES = [
  "Learning Web Development",
  "HTML & CSS Enthusiast",
  "Beginner Programmer",
  "Building Projects",
  "Growing Developer",
];

const TECH_STACK = [
  { name: "HTML", color: "#E34C26", icon: "🏷" },
  { name: "CSS", color: "#1572B6", icon: "🎨" },
  { name: "C++", color: "#00599C", icon: "+" },
  { name: "Python", color: "#3776AB", icon: "🐍" },
];

function useTypewriter(words: string[], speed = 80, pause = 2000) {
  const [displayed, setDisplayed] = useState("");
  const [wordIndex, setWordIndex] = useState(0);
  const [charIndex, setCharIndex] = useState(0);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const current = words[wordIndex];
    let timeout: ReturnType<typeof setTimeout>;

    if (!deleting && charIndex < current.length) {
      timeout = setTimeout(() => setCharIndex((c) => c + 1), speed);
    } else if (!deleting && charIndex === current.length) {
      timeout = setTimeout(() => setDeleting(true), pause);
    } else if (deleting && charIndex > 0) {
      timeout = setTimeout(() => setCharIndex((c) => c - 1), speed / 2);
    } else if (deleting && charIndex === 0) {
      setDeleting(false);
      setWordIndex((i) => (i + 1) % words.length);
    }

    setDisplayed(current.slice(0, charIndex));
    return () => clearTimeout(timeout);
  }, [charIndex, deleting, wordIndex, words, speed, pause]);

  return displayed;
}

function useScrollReveal(threshold = 0.15) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setVisible(true); obs.disconnect(); } },
      { threshold }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold]);

  return { ref, visible };
}

export { useScrollReveal };

export default function Hero() {
  const role = useTypewriter(ROLES);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setMounted(true), 100);
    return () => clearTimeout(t);
  }, []);

  return (
    <section
      id="hero"
      className="relative min-h-screen flex flex-col justify-center overflow-hidden"
      style={{
        background: "#050A0E",
      }}
    >
      {/* Background image */}
      <div
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: `url(https://d2xsxph8kpxj0f.cloudfront.net/310519663399279535/SmGgvUggVdsCXxorozSsRP/hero-bg-n6vHYgfoBctoB6Y4rtASrv.webp)`,
          backgroundSize: "cover",
          backgroundPosition: "center bottom",
          opacity: 0.45,
        }}
      />
      {/* Dark gradient overlay */}
      <div
        className="absolute inset-0 z-0"
        style={{
          background: "linear-gradient(135deg, rgba(5,10,14,0.97) 0%, rgba(5,10,14,0.75) 50%, rgba(5,10,14,0.92) 100%)",
        }}
      />

      {/* Radial glow */}
      <div
        className="absolute inset-0 z-0 pointer-events-none"
        style={{
          background: "radial-gradient(ellipse 60% 50% at 20% 60%, rgba(0, 255, 135, 0.06) 0%, transparent 70%)",
        }}
      />

      {/* Grid lines decoration */}
      <div
        className="absolute inset-0 z-0 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(rgba(0, 255, 135, 0.025) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0, 255, 135, 0.025) 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
      />

      {/* Content */}
      <div className="container relative z-10 pt-24 pb-16">
        <div className="max-w-4xl">
          {/* Status badge */}
          <div
            className={`flex items-center gap-2 mb-8 transition-all duration-700 ${mounted ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}
            style={{ transitionDelay: "0.1s" }}
          >
            <div className="neon-dot" />
            <span
              style={{
                fontFamily: "JetBrains Mono, monospace",
                fontSize: "0.72rem",
                color: "var(--neon)",
                letterSpacing: "0.15em",
                textTransform: "uppercase",
              }}
            >
              Available for work
            </span>
          </div>

          {/* Name */}
          <div
            className={`transition-all duration-700 ${mounted ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}
            style={{ transitionDelay: "0.2s" }}
          >
            <p
              style={{
                fontFamily: "JetBrains Mono, monospace",
                fontSize: "0.8rem",
                color: "var(--slate)",
                letterSpacing: "0.2em",
                textTransform: "uppercase",
                marginBottom: "0.5rem",
              }}
            >
              Hello, I'm
            </p>
            <h1
              style={{
                fontFamily: "Syne, sans-serif",
                fontWeight: 800,
                fontSize: "clamp(3rem, 8vw, 7rem)",
                lineHeight: 1.0,
                letterSpacing: "-0.03em",
                color: "#fff",
                marginBottom: "0.25rem",
              }}
            >
              Desmond
            </h1>
            <h1
              style={{
                fontFamily: "Syne, sans-serif",
                fontWeight: 800,
                fontSize: "clamp(3rem, 8vw, 7rem)",
                lineHeight: 1.0,
                letterSpacing: "-0.03em",
                color: "var(--neon)",
                marginBottom: "1.5rem",
                textShadow: "0 0 40px rgba(0, 255, 135, 0.3)",
              }}
            >
              Kumah
            </h1>
          </div>

          {/* Typewriter role */}
          <div
            className={`flex items-center gap-0 mb-8 transition-all duration-700 ${mounted ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}
            style={{ transitionDelay: "0.35s", minHeight: "2rem" }}
          >
            <span
              style={{
                fontFamily: "JetBrains Mono, monospace",
                fontSize: "clamp(0.9rem, 2.5vw, 1.2rem)",
                color: "var(--slate)",
                fontWeight: 400,
              }}
            >
              {role}
            </span>
            <span className="cursor-blink" />
          </div>

          {/* Description */}
          <p
            className={`mb-10 max-w-xl transition-all duration-700 ${mounted ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}
            style={{
              transitionDelay: "0.45s",
              fontFamily: "Outfit, sans-serif",
              fontSize: "1rem",
              color: "var(--slate)",
              lineHeight: 1.8,
            }}
          >
            I'm a beginner programmer learning web development and programming fundamentals. Currently building projects with HTML and CSS, and progressing in C++ and Python. Passionate about learning and growing as a developer.
          </p>

          {/* CTA Buttons */}
          <div
            className={`flex flex-wrap gap-4 mb-14 transition-all duration-700 ${mounted ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}
            style={{ transitionDelay: "0.55s" }}
          >
            <a
              href="https://github.com/Desmond-Kumah"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-neon-solid"
            >
              <Github size={15} />
              GitHub Profile
            </a>
            <a
              href="#projects"
              className="btn-neon"
              onClick={(e) => {
                e.preventDefault();
                document.querySelector("#projects")?.scrollIntoView({ behavior: "smooth" });
              }}
            >
              View Projects
              <ExternalLink size={13} />
            </a>
          </div>

          {/* Tech stack */}
          <div
            className={`transition-all duration-700 ${mounted ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}
            style={{ transitionDelay: "0.65s" }}
          >
            <p
              style={{
                fontFamily: "JetBrains Mono, monospace",
                fontSize: "0.68rem",
                color: "rgba(148, 163, 184, 0.5)",
                letterSpacing: "0.15em",
                textTransform: "uppercase",
                marginBottom: "0.75rem",
              }}
            >
              Tech Stack
            </p>
            <div className="flex flex-wrap gap-2">
              {TECH_STACK.map((tech) => (
                <div
                  key={tech.name}
                  className="tech-tag flex items-center gap-1.5"
                  title={tech.name}
                >
                  <span style={{ fontSize: "0.85em" }}>{tech.icon}</span>
                  {tech.name}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-2"
        style={{ opacity: 0.5 }}
      >
        <span
          style={{
            fontFamily: "JetBrains Mono, monospace",
            fontSize: "0.65rem",
            color: "var(--slate)",
            letterSpacing: "0.15em",
            textTransform: "uppercase",
          }}
        >
          scroll
        </span>
        <ArrowDown size={14} color="var(--neon)" className="animate-bounce" />
      </div>
    </section>
  );
}
