/* ============================================================
   DESIGN: Cyberpunk Minimal Blog Section
   - Article cards with category tags and read time
   - Neon border hover reveal
   - External link to full articles
   ============================================================ */

import { useRef, useEffect, useState } from "react";
import { ArrowUpRight, Clock, Calendar } from "lucide-react";

const POSTS = [
  {
    id: 1,
    title: "Building a Distributed Key-Value Store with Go and Raft",
    excerpt:
      "A deep dive into implementing the Raft consensus algorithm from scratch in Go, covering leader election, log replication, and fault tolerance in distributed systems.",
    category: "Systems Programming",
    readTime: "18 min read",
    date: "Feb 12, 2026",
    tags: ["Go", "Distributed Systems", "Raft"],
    href: "#",
    featured: true,
  },
  {
    id: 2,
    title: "TypeScript Generics: Beyond the Basics",
    excerpt:
      "Exploring advanced TypeScript patterns — conditional types, infer keyword, template literal types, and how to build truly type-safe APIs that eliminate runtime errors.",
    category: "TypeScript",
    readTime: "12 min read",
    date: "Jan 28, 2026",
    tags: ["TypeScript", "Type System", "Patterns"],
    href: "#",
    featured: false,
  },
  {
    id: 3,
    title: "React Server Components: The Architecture Shift",
    excerpt:
      "How RSC fundamentally changes the mental model for React applications, when to use them, and the performance implications for data-heavy applications.",
    category: "React",
    readTime: "10 min read",
    date: "Jan 15, 2026",
    tags: ["React", "Next.js", "Performance"],
    href: "#",
    featured: false,
  },
  {
    id: 4,
    title: "Optimizing PostgreSQL for High-Throughput APIs",
    excerpt:
      "Practical techniques for PostgreSQL performance: connection pooling with PgBouncer, query optimization, partial indexes, and EXPLAIN ANALYZE deep dives.",
    category: "Database",
    readTime: "15 min read",
    date: "Dec 30, 2025",
    tags: ["PostgreSQL", "Performance", "Backend"],
    href: "#",
    featured: false,
  },
  {
    id: 5,
    title: "Zero-Downtime Deployments with Kubernetes",
    excerpt:
      "Rolling updates, blue-green deployments, and canary releases in Kubernetes. How to achieve true zero-downtime with proper health checks and graceful shutdown.",
    category: "DevOps",
    readTime: "14 min read",
    date: "Dec 10, 2025",
    tags: ["Kubernetes", "DevOps", "CI/CD"],
    href: "#",
    featured: false,
  },
  {
    id: 6,
    title: "GraphQL vs REST in 2026: A Pragmatic Comparison",
    excerpt:
      "Moving beyond the hype — when GraphQL genuinely solves problems, when REST is the better choice, and how to make the decision based on your team's context.",
    category: "API Design",
    readTime: "9 min read",
    date: "Nov 22, 2025",
    tags: ["GraphQL", "REST", "API Design"],
    href: "#",
    featured: false,
  },
];

const CATEGORY_COLORS: Record<string, string> = {
  "Systems Programming": "#F87171",
  TypeScript: "#60A5FA",
  React: "#34D399",
  Database: "#A78BFA",
  DevOps: "#FBBF24",
  "API Design": "#FB923C",
};

function useScrollReveal(threshold = 0.1) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setVisible(true); obs.disconnect(); } },
      { threshold }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, visible };
}

function BlogCard({ post, index }: { post: typeof POSTS[0]; index: number }) {
  const { ref, visible } = useScrollReveal(0.1);
  const catColor = CATEGORY_COLORS[post.category] || "var(--neon)";

  return (
    <div
      ref={ref}
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? "translateY(0)" : "translateY(24px)",
        transition: `opacity 0.6s ease ${index * 0.1}s, transform 0.6s ease ${index * 0.1}s`,
      }}
    >
    <a
      href={post.href}
      className="card-neon rounded-sm p-6 flex flex-col gap-4 group relative overflow-hidden block"
      style={{
        textDecoration: "none",
      }}
    >
      {/* Category color bar */}
      <div
        className="absolute top-0 left-0 w-1 h-full"
        style={{ background: catColor, opacity: 0.6 }}
      />

      {/* Arrow icon */}
      <div
        className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
        style={{ color: "var(--neon)" }}
      >
        <ArrowUpRight size={16} />
      </div>

      {/* Category */}
      <span
        style={{
          fontFamily: "JetBrains Mono, monospace",
          fontSize: "0.65rem",
          color: catColor,
          letterSpacing: "0.12em",
          textTransform: "uppercase",
          fontWeight: 500,
        }}
      >
        {post.category}
      </span>

      {/* Title */}
      <h3
        className="group-hover:text-white transition-colors duration-200"
        style={{
          fontFamily: "Syne, sans-serif",
          fontWeight: 700,
          fontSize: "1.05rem",
          color: "#e2e8f0",
          lineHeight: 1.3,
          letterSpacing: "-0.01em",
        }}
      >
        {post.title}
      </h3>

      {/* Excerpt */}
      <p
        style={{
          fontFamily: "Outfit, sans-serif",
          fontSize: "0.875rem",
          color: "var(--slate)",
          lineHeight: 1.7,
          flex: 1,
        }}
      >
        {post.excerpt}
      </p>

      {/* Tags */}
      <div className="flex flex-wrap gap-1.5">
        {post.tags.map((tag) => (
          <span key={tag} className="tech-tag">{tag}</span>
        ))}
      </div>

      {/* Meta */}
      <div
        className="flex items-center gap-4 pt-3 border-t"
        style={{ borderColor: "rgba(255,255,255,0.06)" }}
      >
        <span
          className="flex items-center gap-1.5"
          style={{ fontFamily: "JetBrains Mono, monospace", fontSize: "0.7rem", color: "rgba(148,163,184,0.6)" }}
        >
          <Calendar size={11} />
          {post.date}
        </span>
        <span
          className="flex items-center gap-1.5"
          style={{ fontFamily: "JetBrains Mono, monospace", fontSize: "0.7rem", color: "rgba(148,163,184,0.6)" }}
        >
          <Clock size={11} />
          {post.readTime}
        </span>
      </div>
    </a>
    </div>
  );
}

export default function Blog() {
  const { ref: headerRef, visible: headerVisible } = useScrollReveal(0.2);

  return (
    <section id="blog" className="py-24 relative overflow-hidden" style={{ background: "#050A0E" }}>
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: "radial-gradient(ellipse 60% 40% at 80% 20%, rgba(0, 255, 135, 0.04) 0%, transparent 70%)",
        }}
      />
      <div className="container relative z-10">
        {/* Header */}
        <div
          ref={headerRef}
          className="mb-16"
          style={{
            opacity: headerVisible ? 1 : 0,
            transform: headerVisible ? "translateY(0)" : "translateY(20px)",
            transition: "opacity 0.6s ease, transform 0.6s ease",
          }}
        >
          <span className="section-label">04</span>
          <h2
            className="mt-3"
            style={{
              fontFamily: "Syne, sans-serif",
              fontWeight: 800,
              fontSize: "clamp(2rem, 5vw, 3.5rem)",
              color: "#fff",
              letterSpacing: "-0.02em",
              lineHeight: 1.1,
            }}
          >
            Technical Writing
          </h2>
          <p
            className="mt-4 max-w-lg"
            style={{ fontFamily: "Outfit, sans-serif", fontSize: "0.95rem", color: "var(--slate)", lineHeight: 1.7 }}
          >
            Long-form articles on systems design, performance engineering, and
            modern web development. Written for engineers who want depth, not fluff.
          </p>
          <div className="scan-divider mt-8" />
        </div>

        {/* Blog grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {POSTS.map((post, i) => (
            <BlogCard key={post.id} post={post} index={i} />
          ))}
        </div>

        {/* View all */}
        <div className="mt-12 flex justify-center">
          <a
            href="https://dev.to/desmondkumah"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-neon"
          >
            Read All Articles
            <ArrowUpRight size={14} />
          </a>
        </div>
      </div>
    </section>
  );
}
