/* ============================================================
   DESIGN: Cyberpunk Minimal About Section
   - Two-column layout: text left, visual right
   - Code-block aesthetic for bio
   - About visual image
   ============================================================ */

import { useRef, useEffect, useState } from "react";
import { MapPin, BookOpen, Zap, Code } from "lucide-react";

function useScrollReveal(threshold = 0.1) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setVisible(true); obs.disconnect(); } },
      { threshold }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, visible };
}

const FACTS = [
  { icon: MapPin, text: "Ghana" },
  { icon: Code, text: "Learning to Code" },
  { icon: BookOpen, text: "Building Projects" },
  { icon: Zap, text: "Passionate Learner" },
];

export default function About() {
  const { ref: sectionRef, visible } = useScrollReveal(0.15);

  return (
    <section id="about" className="py-24 relative overflow-hidden" style={{ background: "#0D1117" }}>
      {/* Subtle radial glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: "radial-gradient(ellipse 50% 60% at 80% 50%, rgba(0, 255, 135, 0.04) 0%, transparent 70%)",
        }}
      />
      <div className="container relative z-10">
        <div
          ref={sectionRef}
          className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center"
        >
          {/* Left: Text */}
          <div
            style={{
              opacity: visible ? 1 : 0,
              transform: visible ? "translateX(0)" : "translateX(-24px)",
              transition: "opacity 0.7s ease, transform 0.7s ease",
            }}
          >
            <span className="section-label">01</span>
            <h2
              className="mt-3 mb-6"
              style={{
                fontFamily: "Syne, sans-serif",
                fontWeight: 800,
                fontSize: "clamp(2rem, 5vw, 3.5rem)",
                color: "#fff",
                letterSpacing: "-0.02em",
                lineHeight: 1.1,
              }}
            >
              About Me
            </h2>

            <div className="flex flex-col gap-4 mb-8">
              <p style={{ fontFamily: "Outfit, sans-serif", fontSize: "0.95rem", color: "var(--slate)", lineHeight: 1.8 }}>
                I'm a beginner programmer passionate about learning web development and programming fundamentals. I'm currently building projects with HTML and CSS, and exploring C++ and Python.
              </p>
              <p style={{ fontFamily: "Outfit, sans-serif", fontSize: "0.95rem", color: "var(--slate)", lineHeight: 1.8 }}>
                My goal is to grow as a developer, understand core programming concepts, and create meaningful projects. I love learning new things and challenging myself to improve every day.
              </p>
            </div>

            {/* Facts */}
            <div className="grid grid-cols-2 gap-4">
              {FACTS.map(({ icon: Icon, text }) => (
                <div
                  key={text}
                  className="flex items-center gap-3 p-3 rounded-sm"
                  style={{
                    background: "rgba(0, 255, 135, 0.05)",
                    border: "1px solid rgba(0, 255, 135, 0.15)",
                    transition: "all 0.3s ease",
                  }}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLElement).style.background = "rgba(0, 255, 135, 0.1)";
                    (e.currentTarget as HTMLElement).style.borderColor = "rgba(0, 255, 135, 0.3)";
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLElement).style.background = "rgba(0, 255, 135, 0.05)";
                    (e.currentTarget as HTMLElement).style.borderColor = "rgba(0, 255, 135, 0.15)";
                  }}
                >
                  <Icon size={16} color="var(--neon)" />
                  <span style={{ fontFamily: "Outfit, sans-serif", fontSize: "0.8rem", color: "var(--slate)" }}>
                    {text}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Visual */}
          <div
            style={{
              opacity: visible ? 1 : 0,
              transform: visible ? "translateX(0)" : "translateX(24px)",
              transition: "opacity 0.7s ease 0.2s, transform 0.7s ease 0.2s",
            }}
          >
            <div
              style={{
                aspectRatio: "1",
                borderRadius: "4px",
                overflow: "hidden",
                border: "1px solid rgba(0, 255, 135, 0.2)",
                background: "linear-gradient(135deg, rgba(0, 255, 135, 0.1) 0%, rgba(0, 255, 135, 0.05) 100%)",
              }}
            >
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663399279535/SmGgvUggVdsCXxorozSsRP/about-visual-n6vHYgfoBctoB6Y4rtASrv.webp"
                alt="About visual"
                style={{
                  width: "100%",
                  height: "100%",
                  objectFit: "cover",
                  opacity: 0.9,
                }}
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
