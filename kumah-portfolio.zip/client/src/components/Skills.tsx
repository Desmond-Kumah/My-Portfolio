/* ============================================================
   DESIGN: Cyberpunk Minimal Skills Matrix
   - Categorized skill groups with animated fill bars
   - Background: skills-bg texture with dark overlay
   - Proficiency levels: Expert / Advanced / Proficient / Learning
   ============================================================ */

import { useRef, useEffect, useState } from "react";

const SKILL_CATEGORIES = [
  {
    category: "Web Development",
    icon: "🌐",
    skills: [
      { name: "HTML", level: 80, label: "Proficient" },
      { name: "CSS", level: 75, label: "Proficient" },
    ],
  },
  {
    category: "Programming",
    icon: "💻",
    skills: [
      { name: "C++", level: 45, label: "Learning" },
      { name: "Python", level: 50, label: "Learning" },
    ],
  },
];

const LEVEL_COLORS: Record<string, string> = {
  Expert: "#00FF87",
  Advanced: "#60A5FA",
  Proficient: "#A78BFA",
  Learning: "#FBBF24",
};

function SkillBar({ name, level, label, delay }: { name: string; level: number; label: string; delay: number }) {
  const [filled, setFilled] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setTimeout(() => setFilled(true), delay);
          obs.disconnect();
        }
      },
      { threshold: 0.3 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [delay]);

  return (
    <div ref={ref} className="flex flex-col gap-1.5">
      <div className="flex items-center justify-between">
        <span
          style={{
            fontFamily: "Outfit, sans-serif",
            fontSize: "0.875rem",
            color: "#e2e8f0",
            fontWeight: 500,
          }}
        >
          {name}
        </span>
        <span
          style={{
            fontFamily: "JetBrains Mono, monospace",
            fontSize: "0.65rem",
            color: LEVEL_COLORS[label],
            letterSpacing: "0.1em",
            textTransform: "uppercase",
            fontWeight: 600,
          }}
        >
          {label}
        </span>
      </div>
      <div
        style={{
          width: "100%",
          height: "6px",
          background: "rgba(255,255,255,0.05)",
          borderRadius: "2px",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            width: filled ? `${level}%` : "0%",
            height: "100%",
            background: `linear-gradient(90deg, ${LEVEL_COLORS[label]}, ${LEVEL_COLORS[label]}dd)`,
            borderRadius: "2px",
            transition: "width 1.2s cubic-bezier(0.34, 1.56, 0.64, 1)",
            boxShadow: `0 0 12px ${LEVEL_COLORS[label]}40`,
          }}
        />
      </div>
    </div>
  );
}

export default function Skills() {
  const { ref: sectionRef, visible } = useScrollReveal(0.15);

  return (
    <section id="skills" style={{ background: "#050A0E", position: "relative", overflow: "hidden" }}>
      {/* Background texture */}
      <div
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: `url(https://d2xsxph8kpxj0f.cloudfront.net/310519663399279535/SmGgvUggVdsCXxorozSsRP/skills-bg-n6vHYgfoBctoB6Y4rtASrv.webp)`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          opacity: 0.15,
        }}
      />

      {/* Radial glow */}
      <div
        className="absolute inset-0 z-0 pointer-events-none"
        style={{
          background: "radial-gradient(ellipse 60% 50% at 80% 40%, rgba(0, 255, 135, 0.06) 0%, transparent 70%)",
        }}
      />

      {/* Grid lines */}
      <div
        className="absolute inset-0 z-0 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(rgba(0, 255, 135, 0.025) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0, 255, 135, 0.025) 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
      />

      {/* Content */}
      <div className="container relative z-10 py-24">
        <div ref={sectionRef}>
          {/* Section header */}
          <div
            style={{
              opacity: visible ? 1 : 0,
              transform: visible ? "translateY(0)" : "translateY(24px)",
              transition: "opacity 0.7s ease, transform 0.7s ease",
            }}
          >
            <span className="section-label">03</span>
            <h2
              className="mt-3 mb-16"
              style={{
                fontFamily: "Syne, sans-serif",
                fontWeight: 800,
                fontSize: "clamp(2rem, 5vw, 3.5rem)",
                color: "#fff",
                letterSpacing: "-0.02em",
                lineHeight: 1.1,
              }}
            >
              Skills &<br />
              <span style={{ color: "var(--neon)" }}>Expertise</span>
            </h2>
          </div>

          {/* Skills grid */}
          <div
            className="grid grid-cols-1 lg:grid-cols-2 gap-12"
            style={{
              opacity: visible ? 1 : 0,
              transform: visible ? "translateY(0)" : "translateY(24px)",
              transition: "opacity 0.7s ease 0.1s, transform 0.7s ease 0.1s",
            }}
          >
            {SKILL_CATEGORIES.map((cat, idx) => (
              <div
                key={cat.category}
                style={{
                  padding: "1.5rem",
                  background: "rgba(255,255,255,0.02)",
                  border: "1px solid rgba(0, 255, 135, 0.1)",
                  borderRadius: "4px",
                  transition: "all 0.3s ease",
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLElement).style.borderColor = "rgba(0, 255, 135, 0.3)";
                  (e.currentTarget as HTMLElement).style.background = "rgba(0, 255, 135, 0.04)";
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLElement).style.borderColor = "rgba(0, 255, 135, 0.1)";
                  (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.02)";
                }}
              >
                <div className="flex items-center gap-3 mb-6">
                  <span style={{ fontSize: "1.5rem" }}>{cat.icon}</span>
                  <h3
                    style={{
                      fontFamily: "Syne, sans-serif",
                      fontSize: "1.1rem",
                      fontWeight: 700,
                      color: "#fff",
                      letterSpacing: "-0.01em",
                    }}
                  >
                    {cat.category}
                  </h3>
                </div>
                <div className="flex flex-col gap-5">
                  {cat.skills.map((skill, skillIdx) => (
                    <SkillBar
                      key={skill.name}
                      name={skill.name}
                      level={skill.level}
                      label={skill.label}
                      delay={idx * 100 + skillIdx * 80}
                    />
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function useScrollReveal(threshold = 0.15) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          obs.disconnect();
        }
      },
      { threshold }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold]);

  return { ref, visible };
}
