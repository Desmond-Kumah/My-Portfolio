/* ============================================================
   DESMOND KUMAH PORTFOLIO - VANILLA JAVASCRIPT
   Interactive Features & Smooth Scrolling
   ============================================================ */

// ============================================================
// 1. MOBILE MENU TOGGLE
// ============================================================

const hamburger = document.querySelector('.hamburger');
const navMenu = document.querySelector('.nav-menu');
const navLinks = document.querySelectorAll('.nav-link');

// Toggle mobile menu
hamburger.addEventListener('click', () => {
    navMenu.classList.toggle('active');
    hamburger.classList.toggle('active');
});

// Close menu when a link is clicked
navLinks.forEach(link => {
    link.addEventListener('click', () => {
        navMenu.classList.remove('active');
        hamburger.classList.remove('active');
    });
});

// ============================================================
// 2. ACTIVE NAVIGATION LINK ON SCROLL
// ============================================================

window.addEventListener('scroll', () => {
    let current = '';
    
    // Get all sections
    const sections = document.querySelectorAll('section');
    
    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.clientHeight;
        
        if (pageYOffset >= sectionTop - 200) {
            current = section.getAttribute('id');
        }
    });
    
    // Update active nav link
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href').slice(1) === current) {
            link.classList.add('active');
        }
    });
});

// ============================================================
// 3. SCROLL REVEAL ANIMATION
// ============================================================

const revealElements = () => {
    const elements = document.querySelectorAll('.skill-item, .project-card');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in');
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: '0px 0px -100px 0px'
    });
    
    elements.forEach(el => observer.observe(el));
};

// Call on page load
document.addEventListener('DOMContentLoaded', revealElements);

// ============================================================
// 4. SMOOTH SCROLL FOR ANCHOR LINKS
// ============================================================

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// ============================================================
// 5. FORM VALIDATION (if contact form is added)
// ============================================================

const validateEmail = (email) => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
};

// ============================================================
// 6. DARK MODE TOGGLE (Optional - can be added later)
// ============================================================

// Check for saved theme preference or default to 'dark'
const currentTheme = localStorage.getItem('theme') || 'dark';
document.documentElement.setAttribute('data-theme', currentTheme);

// ============================================================
// 7. PARALLAX EFFECT (Optional Enhancement)
// ============================================================

window.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset;
    const hero = document.querySelector('.hero');
    
    if (hero) {
        hero.style.backgroundPosition = `0 ${scrolled * 0.5}px`;
    }
});

// ============================================================
// 8. PERFORMANCE OPTIMIZATION - LAZY LOADING
// ============================================================

if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.add('loaded');
                observer.unobserve(img);
            }
        });
    });
    
    document.querySelectorAll('img[data-src]').forEach(img => {
        imageObserver.observe(img);
    });
}

// ============================================================
// 9. CONSOLE MESSAGE
// ============================================================

console.log('%cWelcome to Desmond Kumah\'s Portfolio!', 'color: #00d4ff; font-size: 16px; font-weight: bold;');
console.log('%cFeel free to reach out: kumah6128@gmail.com', 'color: #b0b8d4; font-size: 14px;');

// ============================================================
// 10. UTILITY FUNCTIONS
// ============================================================

// Debounce function for scroll events
const debounce = (func, wait) => {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
};

// Throttle function for performance
const throttle = (func, limit) => {
    let inThrottle;
    return function(...args) {
        if (!inThrottle) {
            func.apply(this, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
};

// ============================================================
// 11. PAGE LOAD ANIMATION
// ============================================================

window.addEventListener('load', () => {
    document.body.style.opacity = '1';
});

// ============================================================
// 12. KEYBOARD NAVIGATION
// ============================================================

document.addEventListener('keydown', (e) => {
    // Close mobile menu on Escape
    if (e.key === 'Escape') {
        navMenu.classList.remove('active');
        hamburger.classList.remove('active');
    }
});

// ============================================================
// 13. CONTACT ICON CLICK TRACKING (Optional Analytics)
// ============================================================

const contactIcons = document.querySelectorAll('.contact-icon');

contactIcons.forEach(icon => {
    icon.addEventListener('click', (e) => {
        const platform = icon.classList[1]; // whatsapp, email, github, linkedin
        console.log(`User clicked on ${platform}`);
        // You can add analytics tracking here
    });
});

// ============================================================
// 14. ACCESSIBILITY ENHANCEMENTS
// ============================================================

// Add skip to main content link (optional)
const skipLink = document.createElement('a');
skipLink.href = '#home';
skipLink.className = 'skip-to-content';
skipLink.textContent = 'Skip to main content';
document.body.insertBefore(skipLink, document.body.firstChild);

// Improve focus management
document.addEventListener('keydown', (e) => {
    if (e.key === 'Tab') {
        document.body.classList.add('keyboard-nav');
    }
});

document.addEventListener('mousedown', () => {
    document.body.classList.remove('keyboard-nav');
});
