# Design Brainstorm: Desmond Kumah Portfolio

## Approach 1: Terminal Noir
<response>
<text>
**Design Movement**: Brutalist Terminal / Hacker Aesthetic
**Core Principles**:
- Monospace typography dominates, evoking raw code editors
- Neon green on pure black — maximum contrast, zero compromise
- Asymmetric layouts with intentional "broken" grid feel
- Scanline / CRT texture overlays for depth

**Color Philosophy**: Pure #000000 black as canvas. Neon green (#39FF14) as the singular accent — used sparingly for maximum impact. Slate gray (#64748B) for secondary text and borders. No gradients, no softness.

**Layout Paradigm**: Left-anchored sidebar navigation with full-height sticky nav. Content flows in a single wide column with deliberate negative space. Section dividers are raw horizontal rules or ASCII-style separators.

**Signature Elements**:
- Blinking cursor after name in hero
- Typed-text animation for role descriptor
- Code block aesthetic for skill tags

**Interaction Philosophy**: Hover states reveal neon green underlines. Buttons feel like CLI commands. Click effects are instant, no easing.

**Animation**: Typewriter entrance for hero text. Stagger-fade for project cards. Scroll-triggered line draws for section dividers.

**Typography System**: `JetBrains Mono` for headings and UI labels. `IBM Plex Mono` for body text. Hierarchy via weight (700 → 400) not size variation.
</text>
<probability>0.07</probability>
</response>

## Approach 2: Brutalist Editorial Dark
<response>
<text>
**Design Movement**: Dark Editorial / Swiss Brutalism
**Core Principles**:
- Oversized display typography as a primary design element
- Grid-breaking layouts — elements intentionally overflow or bleed
- High information density balanced by generous whitespace pockets
- Neon green used only for interactive states and key callouts

**Color Philosophy**: Deep charcoal (#0A0A0A) base. Slate gray (#1E293B) for card surfaces. Neon green (#22C55E) for accent only. White for primary text. The palette feels like a premium tech magazine printed at night.

**Layout Paradigm**: Asymmetric two-column hero (name left, large, role descriptor right, small). Project grid uses mixed card sizes — one featured large card + smaller cards. Skills section uses a horizontal scrolling ticker.

**Signature Elements**:
- Large rotated section labels (like editorial chapter markers)
- Thin 1px neon green border accents on cards
- Diagonal clip-path section transitions

**Interaction Philosophy**: Cards lift with subtle shadow on hover. Nav links have a neon green left-border reveal. Smooth scroll with section snap.

**Animation**: Parallax hero background. Cards animate in from bottom on scroll. Section labels slide in from the left.

**Typography System**: `Space Grotesk` for display headings. `DM Mono` for code/labels. `Inter` for body copy. Hierarchy: 96px hero → 48px section → 18px body.
</text>
<probability>0.08</probability>
</response>

## Approach 3: Cyberpunk Minimal (CHOSEN)
<response>
<text>
**Design Movement**: Neo-Noir Minimal / Cyberpunk Grid
**Core Principles**:
- Dark slate surfaces with neon green as the singular energy source
- Geometric precision — everything aligns to an invisible 8px grid
- Sparse use of borders and lines to create structure without weight
- Code-adjacent aesthetic: monospace accents, bracket motifs, hex-style labels

**Color Philosophy**: Background: `#050A0E` (near-black with a blue undertone). Surface: `#0D1117` (GitHub dark). Neon green: `#00FF87` (electric, slightly cyan-shifted). Slate: `#94A3B8`. The palette feels like a terminal running in a dark server room.

**Layout Paradigm**: Full-width hero with name in massive weight, left-aligned. Navigation is a minimal top bar with monospace labels. Sections are full-width with alternating left/right content alignment. No boxed containers — content breathes edge to edge with internal padding.

**Signature Elements**:
- `[ ]` bracket motifs around section numbers/labels
- Neon green dot indicators for "available for work" status
- Thin horizontal scan-line dividers between sections

**Interaction Philosophy**: Hover on project cards reveals a neon green overlay with action buttons. Skills use animated fill bars. Blog cards flip or expand inline.

**Animation**: Hero name animates in with a glitch effect. Scroll-triggered reveals with a slight upward translate + fade. Neon green elements pulse subtly.

**Typography System**: `Syne` (bold, geometric) for display headings. `JetBrains Mono` for labels, tags, and code snippets. `Outfit` for body text. Hierarchy enforced by weight and letter-spacing.
</text>
<probability>0.09</probability>
</response>

---

## Selected Approach: **Cyberpunk Minimal (Approach 3)**

Chosen for its balance of dark aesthetics with neon green energy, geometric precision, and code-adjacent motifs that perfectly suit a full-stack developer portfolio. The `[ ]` bracket motifs and monospace accents reinforce the technical identity without being overwhelming.
